import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { motion, useMotionValue, useSpring } from 'framer-motion';
import { ArrowDownRight, ArrowUpRight, ArrowRight, Menu, X, Github, Linkedin, Mail, Sparkles, Cpu, Trophy, Mic2, Layers3, Globe2, Zap, ExternalLink, Play, ChevronDown } from 'lucide-react';
import './styles.css';

const projects = [
  { n:'01', type:'AI INFRASTRUCTURE', title:'EdgeMind AI', desc:'Exploring privacy-first AI experiences across personal devices, private infrastructure and intelligent workflows.', tags:['AI systems','Privacy','Product design'], symbol:'◈', tone:'mint' },
  { n:'02', type:'PRODUCT CONCEPT', title:'LaunchPilot', desc:'A focused workspace concept for turning early-stage ideas into structured plans, tasks and execution.', tags:['SaaS','Strategy','Automation'], symbol:'↗', tone:'violet' },
  { n:'03', type:'CREATIVE SYSTEMS', title:'Digital Experiments', desc:'A growing collection of interface concepts, AI-assisted builds, visual storytelling and motion experiments.', tags:['React','AI tools','Motion'], symbol:'✳', tone:'orange' },
];
const achievements = [
  { k:'01', title:'Indian Debating League 2025', detail:'Individual round · Rank 11 nationally · State rank 2', icon:Mic2 },
  { k:'02', title:'SAI Global Debate', detail:'Qualified for the global semifinals', icon:Trophy },
  { k:'03', title:'Pragyan 2026 · IIT (BHU)', detail:'Telekinesis team · 6th place', icon:Zap },
  { k:'04', title:'Tenni-Koit / Ring Tennis', detail:'Gold medal · 23rd round · Raj English School, Varanasi', icon:Trophy },
  { k:'05', title:'Shabdnama Theatre', detail:'School team · 2nd place · Ghaziabad', icon:Layers3 },
  { k:'06', title:'IIC Regional Meet 2025', detail:'AICTE event · BIM International, Varuna', icon:Globe2 },
];
const skills = ['AI product thinking','React & UI prototyping','Video editing','Debate & public speaking','Creative direction','Rapid experimentation'];

function Orb() {
  const ref = useRef(null);
  const [tilt, setTilt] = useState({x:0,y:0});
  const onMove = e => { const r=e.currentTarget.getBoundingClientRect(); setTilt({x:((e.clientX-r.left)/r.width-.5)*14,y:((e.clientY-r.top)/r.height-.5)*-14}); };
  return <div className="orb-stage" ref={ref} onMouseMove={onMove} onMouseLeave={()=>setTilt({x:0,y:0})}>
    <motion.div className="orb-wrap" animate={{rotateX:tilt.y,rotateY:tilt.x}} transition={{type:'spring',stiffness:90,damping:18}}>
      <div className="orb-halo"/><div className="orb-core"><div className="orb-shine"/><div className="orb-grid"/><div className="orb-continent c1"/><div className="orb-continent c2"/><div className="orb-continent c3"/></div>
      <div className="orb-ring ring-one"/><div className="orb-ring ring-two"/><div className="orb-ring ring-three"/><div className="orb-dot dot-one"/><div className="orb-dot dot-two"/>
    </motion.div>
    <div className="orb-label label-top"><span className="live-dot"/> CURIOUS BY DEFAULT</div><div className="orb-label label-bottom">IDEAS → SYSTEMS → IMPACT</div>
  </div>;
}
function App(){
 const [menuOpen,setMenuOpen]=useState(false); const [active,setActive]=useState('Home');
 useEffect(()=>{const onScroll=()=>{let current='Home'; document.querySelectorAll('section[id]').forEach(s=>{if(window.scrollY>=s.offsetTop-180)current=s.id[0].toUpperCase()+s.id.slice(1)});setActive(current)};window.addEventListener('scroll',onScroll);return()=>window.removeEventListener('scroll',onScroll)},[]);
 const nav=[['Home','#home'],['About','#about'],['Work','#work'],['Journey','#journey']];
 const jump=id=>{document.querySelector(id)?.scrollIntoView({behavior:'smooth'});setMenuOpen(false)};
 return <div className="site-shell">
  <div className="noise" aria-hidden="true"/><header className="nav-wrap"><a className="brand" href="#home" onClick={e=>{e.preventDefault();jump('#home')}}><span className="brand-mark">A<span>.</span></span><span className="brand-name">AADARSH GUPTA<small>INDEPENDENT MIND · CLASS OF 2027</small></span></a>
   <nav className="desktop-nav">{nav.map(([n,h])=><a key={n} className={active===n?'active':''} href={h} onClick={e=>{e.preventDefault();jump(h)}}>{n}</a>)}</nav>
   <a className="nav-cta" href="mailto:hello@example.com">LET'S CONNECT <ArrowUpRight size={14}/></a>
   <button className="mobile-toggle" aria-label="Toggle navigation" onClick={()=>setMenuOpen(!menuOpen)}>{menuOpen?<X/>:<Menu/>}</button>
  </header>
  {menuOpen&&<div className="mobile-menu">{nav.map(([n,h])=><a key={n} href={h} onClick={e=>{e.preventDefault();jump(h)}}>{n}<ArrowUpRight size={16}/></a>)}<a href="mailto:hello@example.com">Let's connect <ArrowUpRight size={16}/></a></div>}
  <main>
   <section id="home" className="hero section-pad"><div className="hero-copy"><motion.div initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{duration:.7}} className="eyebrow"><span className="eyebrow-line"/> PORTFOLIO / 2026—27 <span className="eyebrow-status">AVAILABLE FOR IDEAS</span></motion.div>
    <motion.h1 initial={{opacity:0,y:24}} animate={{opacity:1,y:0}} transition={{duration:.8,delay:.08}}>I build at the<br/>intersection of <em>ideas</em><span className="period">.</span></motion.h1>
    <motion.p className="hero-sub" initial={{opacity:0}} animate={{opacity:1}} transition={{delay:.3,duration:.7}}>Student. Debater. Builder. I explore how technology, design and clear thinking can turn ambitious ideas into things that work.</motion.p>
    <motion.div className="hero-actions" initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{delay:.4}}><a className="button-primary" href="#work" onClick={e=>{e.preventDefault();jump('#work')}}>Explore my work <ArrowDownRight size={17}/></a><a className="text-link" href="#about" onClick={e=>{e.preventDefault();jump('#about')}}>A little about me <ArrowRight size={15}/></a></motion.div>
    <div className="hero-meta"><div><span className="meta-label">CURRENTLY</span><span>Learning by building</span></div><div><span className="meta-label">BASED IN</span><span>Varanasi, India</span></div><div><span className="meta-label">MINDSET</span><span>Stay curious <span className="lime">↗</span></span></div></div>
   </div><div className="hero-visual"><Orb/><div className="floating-note note-one"><Sparkles size={14}/><span>IDEAS IN MOTION</span></div><div className="floating-note note-two"><span className="note-num">03</span><span>MODES: THINK / BUILD / REFINE</span></div></div>
   <div className="hero-bottomline"><span>SCROLL TO EXPLORE</span><div className="scroll-track"><span/></div><span>01 — 04</span></div>
  </section>
  <section id="about" className="about section-pad"><div className="section-kicker"><span>01 / THE PERSON</span><span className="kicker-line"/></div><div className="about-grid"><div><h2>Curiosity is<br/>my <em>unfair advantage.</em></h2></div><div className="about-copy"><p className="lead">I'm Aadarsh — a student who likes asking better questions, building ambitious things, and learning in public.</p><p>From competitive debating to AI product experiments, I enjoy connecting disciplines that usually sit apart. One day it's a question about human behaviour; the next, it's a prototype, a pitch, or a new way to tell a story.</p><p>This portfolio is a living snapshot of what I'm learning, what I'm making, and what I want to explore next.</p><a className="inline-link" href="#journey" onClick={e=>{e.preventDefault();jump('#journey')}}>Explore the journey <ArrowUpRight size={15}/></a></div></div>
   <div className="principles"><div className="principle"><span className="principle-icon"><Cpu size={18}/></span><span className="principle-title">TECH WITH INTENT</span><p>Build things that solve real problems—not just look impressive.</p></div><div className="principle"><span className="principle-icon"><Mic2 size={18}/></span><span className="principle-title">THINK CLEARLY</span><p>Use research, argument and empathy to test every assumption.</p></div><div className="principle"><span className="principle-icon"><Layers3 size={18}/></span><span className="principle-title">MAKE, THEN REFINE</span><p>Learn through experiments, honest feedback and iteration.</p></div></div>
  </section>
  <section id="work" className="work section-pad"><div className="section-kicker"><span>02 / SELECTED WORK</span><span className="kicker-line"/><span className="kicker-aside">CONCEPTS · EXPERIMENTS · BUILDS</span></div><div className="work-heading"><h2>Ideas, made <em>tangible.</em></h2><p>A selection of projects and directions I'm exploring. Some are early-stage concepts; the goal is always to keep moving from thought to execution.</p></div>
   <div className="project-list">{projects.map((p,i)=><motion.article className={`project-card ${p.tone}`} key={p.n} initial={{opacity:0,y:22}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.2}} transition={{duration:.55,delay:i*.08}}><div className="project-main"><span className="project-num">{p.n} / {p.type}</span><h3>{p.title}</h3><p>{p.desc}</p><div className="tag-row">{p.tags.map(t=><span key={t}>{t}</span>)}</div></div><div className="project-art"><div className="art-orbit orbit-a"/><div className="art-orbit orbit-b"/><div className="art-glyph">{p.symbol}</div><span className="art-caption">FIG. 0{i+1} — EXPLORATION</span></div><span className="project-arrow"><ArrowUpRight size={20}/></span></motion.article>)}</div>
  </section>
  <section id="journey" className="journey section-pad"><div className="section-kicker"><span>03 / THE JOURNEY</span><span className="kicker-line"/></div><div className="journey-heading"><h2>Small steps.<br/><em>Real momentum.</em></h2><p>Proof that showing up, competing, and collaborating can turn curiosity into capability.</p></div>
   <div className="journey-layout"><div className="achievement-list">{achievements.map((a,i)=><motion.div className="achievement" key={a.k} initial={{opacity:0,x:-12}} whileInView={{opacity:1,x:0}} viewport={{once:true,amount:.25}} transition={{delay:i*.04}}><span className="achievement-number">{a.k}</span><span className="achievement-icon"><a.icon size={17}/></span><div className="achievement-text"><h3>{a.title}</h3><p>{a.detail}</p></div><ArrowUpRight className="achievement-arrow" size={16}/></motion.div>)}</div>
   <aside className="toolbox"><div className="toolbox-top"><span>THE TOOLKIT</span><Sparkles size={16}/></div><h3>Many tools.<br/>One curious mind.</h3><p>Tools change. The ability to learn, connect ideas and ship work matters more.</p><div className="skill-cloud">{skills.map((s,i)=><span key={s} style={{'--i':i}}>{s}</span>)}</div><div className="toolbox-foot"><span className="live-dot"/> ALWAYS LEARNING</div></aside></div>
  </section>
  <section id="contact" className="contact section-pad"><div className="contact-glow"/><div className="section-kicker"><span>04 / WHAT'S NEXT</span><span className="kicker-line"/></div><div className="contact-content"><span className="contact-overline">HAVE A GOOD QUESTION?</span><h2>Let's make<br/><em>something matter.</em></h2><p>I'm always interested in thoughtful conversations, ambitious ideas and opportunities to learn with people who build.</p><a className="button-primary contact-button" href="mailto:hello@example.com">Start a conversation <ArrowUpRight size={17}/></a><span className="contact-note">EMAIL PLACEHOLDER — UPDATE BEFORE PUBLISHING</span></div><div className="contact-orbit"><div/><div/><div/></div></section>
  </main>
  <footer className="footer"><a className="footer-brand" href="#home" onClick={e=>{e.preventDefault();jump('#home')}}>A<span>.</span></a><span>DESIGNED WITH INTENTION · BUILT WITH CURIOSITY</span><a href="#home" onClick={e=>{e.preventDefault();jump('#home')}}>BACK TO TOP ↑</a><span className="copyright">© 2026 AADARSH GUPTA</span></footer>
 </div>
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App/></React.StrictMode>);
