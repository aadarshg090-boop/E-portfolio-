/** @type {import('tailwindcss').Config} */
export default { content: ['./index.html','./src/**/*.{js,ts,jsx,tsx}'], theme: { extend: { fontFamily: { sans: ['Manrope','sans-serif'], mono: ['DM Mono','monospace'] }, colors: { ink:'#08090b', lime:'#c8ff5f' } } }, plugins: [] }
