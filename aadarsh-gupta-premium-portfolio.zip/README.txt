Aadarsh Gupta portfolio — Red Edition

Open index.html in a browser, or deploy this folder to a static host such as Vercel.
The hero uses a custom animated AG monogram; no personal photo is included.
All external links are embedded in index.html.
